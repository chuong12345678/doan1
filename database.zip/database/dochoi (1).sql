-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 22, 2017 at 05:00 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dochoi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `dangky`
--

CREATE TABLE IF NOT EXISTS `dangky` (
  `Email` varchar(50) NOT NULL,
  `pass` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `Repass` varchar(50) NOT NULL,
  `Diachi` varchar(50) NOT NULL,
  `SDT` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dangky`
--

INSERT INTO `dangky` (`Email`, `pass`, `Repass`, `Diachi`, `SDT`) VALUES
('anhwadinh911@gmail.com', 'd04ab1aae80708e8d1c1575ac347fb11', 'd04ab1aae80708e8d1c1575ac347fb11', 'ddd', 979050130);

-- --------------------------------------------------------

--
-- Table structure for table `dmsanpham`
--

CREATE TABLE IF NOT EXISTS `dmsanpham` (
  `ProductList` varchar(10) NOT NULL,
  `soluong` int(11) NOT NULL,
  PRIMARY KEY (`ProductList`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dmsanpham`
--

INSERT INTO `dmsanpham` (`ProductList`, `soluong`) VALUES
('Figma', 5),
('PVC', 5),
('S.H.F', 15);

-- --------------------------------------------------------

--
-- Table structure for table `giohang`
--

CREATE TABLE IF NOT EXISTS `giohang` (
  `idgio` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `ProductCode` varchar(20) NOT NULL,
  `soluong` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `codekm` varchar(20) NOT NULL,
  PRIMARY KEY (`idgio`),
  UNIQUE KEY `ProductCode` (`ProductCode`,`email`),
  UNIQUE KEY `ProductCode_2` (`ProductCode`,`email`),
  KEY `email` (`email`),
  KEY `ProductCode_3` (`ProductCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `giohang`
--

INSERT INTO `giohang` (`idgio`, `ProductCode`, `soluong`, `email`, `codekm`) VALUES
('1a2', 'CH', 1, 'hongchuong@gmail.com', '678'),
('1a3', 'CH', 2, 'hoannguyen@gmail.com', '789'),
('3', 'Soft', 5, 'hoannguyen@gmail.com', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `Home` varchar(50) NOT NULL,
  `Giới Thiệu` varchar(50) NOT NULL,
  `Giao Hàng` varchar(50) NOT NULL,
  `Liên hệ` varchar(50) NOT NULL,
  PRIMARY KEY (`Home`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`Home`, `Giới Thiệu`, `Giao Hàng`, `Liên hệ`) VALUES
('index.php', 'index.php', 'special_offer.html', 'https://www.facebook.com/anhlaai.anhlaanh');

-- --------------------------------------------------------

--
-- Table structure for table `productdetail`
--

CREATE TABLE IF NOT EXISTS `productdetail` (
  `ProductCode` varchar(20) NOT NULL,
  `ProductName` varchar(20) NOT NULL,
  `ProductList` varchar(20) NOT NULL,
  `nhasx` varchar(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  `image2` varchar(20) NOT NULL,
  `image3` varchar(20) NOT NULL,
  `price` float NOT NULL,
  `mota` varchar(20) NOT NULL,
  `link` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  PRIMARY KEY (`ProductCode`),
  UNIQUE KEY `image_2` (`image`),
  UNIQUE KEY `image` (`image`),
  KEY `ProductCode` (`ProductCode`),
  KEY `ProductName` (`ProductName`),
  KEY `ProductList` (`ProductList`),
  KEY `price` (`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `productdetail`
--

INSERT INTO `productdetail` (`ProductCode`, `ProductName`, `ProductList`, `nhasx`, `image`, `image2`, `image3`, `price`, `mota`, `link`) VALUES
('CH', 'Cuphead ', 'PVC', 'americans Toy', 'themes/images/products/ch2.jpg', 'themes/images/produc', '', 100000, 'la 1 san phẩm có trị', 'face'),
('DN', 'Dino tranfor', 'PVC', '', 'themes/images/products/bd1.jpg', '', '', 100000, '', ''),
('Dnps', 'Khủng long nhựa', 'PVC', 'americans Toy nic', '	themes/images/products/pk2.jpg', '', '', 200000, 'đồ chơi lắp ghép', ''),
('HW', 'Hot wheel', 'Figma', 'china joy', '	themes/images/products/w3.jpg', '', '', 500000, '', ''),
('LG', 'Lắp ráp', 'PVC', 'taiwai', 'themes/images/products/dn1.jpg', '', '', 100000, '1 loại đồ chơi làm b', ''),
('NJ', 'NInja turtle', 'PVC', '', 'themes/images/products/nj1.jpg', '', '', 100000, '1 mô hình theo nhân ', ''),
('RB', 'Ro Bot Nhựa', 'S.H.F', 'american toy', 'themes/images/products/robo4.jpg', '', '', 60000, '', ''),
('Soft', 'Cục dẻo', 'PVC', 'americans Toy nic', 'themes/images/products/n1.jpg', '', '', 60000, 'day la 1 laoi do cho', '');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE IF NOT EXISTS `sanpham` (
  `ProductName` varchar(50) NOT NULL,
  `ProductCode` varchar(5) NOT NULL,
  `image` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `ProductList` varchar(10) NOT NULL,
  PRIMARY KEY (`ProductCode`),
  UNIQUE KEY `image_2` (`image`),
  KEY `ProductList` (`ProductList`),
  KEY `ProductName` (`ProductName`),
  KEY `image` (`image`),
  KEY `price` (`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`ProductName`, `ProductCode`, `image`, `price`, `ProductList`) VALUES
('Cuphead ', 'CH', 'themes/images/products/ch2.jpg', 100000, 'PVC'),
('Dino tranfor', 'DN', 'themes/images/products/bd1.jpg', 300000, 'PVC'),
('Khủng long nhựa', 'Dnps', '	themes/images/products/pk2.jpg', 200000, 'PVC'),
('Hot wheel', 'HW', '	themes/images/products/w3.jpg', 500000, 'Figma'),
('Lắp ráp', 'LG', 'themes/images/products/dn1.jpg', 100000, 'PVC'),
('NInja turtle', 'NJ', 'themes/images/products/nj1.jpg', 100000, 'S.H.F'),
('Pokemon', 'PK', '	themes/images/products/pk1.jpg', 50000, 'PVC'),
('Ro Bot Nhựa', 'RB', 'themes/images/products/robo4.jpg', 60000, 'S.H.F'),
('Cục dẻo', 'Soft', 'themes/images/products/n1.jpg', 300000, 'Figma'),
('Sieu nhân', 'SP', '	themes/images/products/sp2.jpg', 450000, 'PVC'),
('Xe truck', 'TC', '	themes/images/products/t2.jpg', 70000, 'PVC'),
('Wall E', 'WE', '	themes/images/products/w1.jpg', 500000, 'Figma');

-- --------------------------------------------------------

--
-- Table structure for table `thanhtoan`
--

CREATE TABLE IF NOT EXISTS `thanhtoan` (
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Diachi` varchar(50) NOT NULL,
  `Tinh` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `Thanhtoan` varchar(50) NOT NULL,
  `Phiship` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `sdt` int(11) NOT NULL,
  `tongtien` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `thanhtoan`
--

INSERT INTO `thanhtoan` (`Name`, `Email`, `Diachi`, `Tinh`, `Thanhtoan`, `Phiship`, `product`, `sdt`, `tongtien`) VALUES
('Chuong', 'anhwadinh911@gmail.com', '09', 'Sài Gòn', 'Chuyển khoảng', 20000, 'tên sản phẫm là:Cuphead |số lượng là:1     ', 979050130, 100000),
('aa', 'anhwadinh911@gmail.com', '00', 'Sài Gòn', 'Chuyển khoảng', 0, 'tên sản phẫm là:Cuphead |số lượng là:1     ', 979050130, 100000),
('a', 'anhwadinh911@gmail.com', '999', 'Cần Thơ', 'Chuyển khoảng', 0, 'tên sản phẫm là:Cuphead |số lượng là:1     ', 979050130, 100000),
('a', 'anhwadinh911@gmail.com', '999', 'Cần Thơ', 'Chuyển khoảng', 0, 'tên sản phẫm là:Cuphead |số lượng là:1     ', 979050130, 100000),
('Phạm Hồng Chương', 'anhwadinh911@gmail.com', '09', 'Sài Gòn', 'Chuyển khoảng', 0, 'tên sản phẫm là:Cuphead |số lượng là:3     ', 979050130, 300000),
('Chuong', 'anhwadinh911@gmail.com', '09O1', 'Long An', 'Chuyển khoảng', 0, 'tên sản phẫm là:Cuphead |số lượng là:1     ', 979050130, 100000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `email` varchar(20) NOT NULL,
  `diachi` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `hoten` varchar(20) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`email`, `diachi`, `pass`, `hoten`) VALUES
('hoannguyen@gmail.com', 'caolo', '0000', 'nguyen'),
('hongchuong@gmail.com', 'Q4', '12345', 'chuong');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `giohang`
--
ALTER TABLE `giohang`
  ADD CONSTRAINT `giohang_ibfk_1` FOREIGN KEY (`ProductCode`) REFERENCES `sanpham` (`ProductCode`) ON UPDATE CASCADE,
  ADD CONSTRAINT `giohang_ibfk_2` FOREIGN KEY (`email`) REFERENCES `user` (`email`) ON UPDATE CASCADE;

--
-- Constraints for table `productdetail`
--
ALTER TABLE `productdetail`
  ADD CONSTRAINT `productdetail_ibfk_45` FOREIGN KEY (`ProductCode`) REFERENCES `sanpham` (`ProductCode`) ON UPDATE CASCADE,
  ADD CONSTRAINT `productdetail_ibfk_46` FOREIGN KEY (`ProductName`) REFERENCES `sanpham` (`ProductName`) ON UPDATE CASCADE,
  ADD CONSTRAINT `productdetail_ibfk_47` FOREIGN KEY (`ProductList`) REFERENCES `dmsanpham` (`ProductList`) ON UPDATE CASCADE,
  ADD CONSTRAINT `productdetail_ibfk_48` FOREIGN KEY (`image`) REFERENCES `sanpham` (`image`) ON UPDATE CASCADE,
  ADD CONSTRAINT `productdetail_ibfk_49` FOREIGN KEY (`price`) REFERENCES `sanpham` (`price`) ON UPDATE CASCADE;

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`ProductList`) REFERENCES `dmsanpham` (`ProductList`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
