	
<meta charset="utf-8">
<head>
				  <?php
				  isset($_SESSION)?$_SESSION:"";
				 
				  ?>
                  
                 <div class="span6">Welcome!<strong>:
				 <?php 	
				 if(isset($_SESSION['email']))
				 {
	 				echo isset($_SESSION['email'])?$_SESSION['email']:"";
				 }
				 
	?></strong></div>
            </table>
                  </form>
                  <div style="margin-left:10px">
                  <table style="background-color:#8EE8FB" border="3px">
                  <tr>
                  <td>Tổng thanh toán là:</td>
                  <td><?php echo $tongtien;  ?></td>
                  
                  </table>
                  </div>
           </div>
           </head>
          
        <body >
           <center><p style="color:#BF3B3D">Điền thông tin của bạn</p></center>

<center><form  style="width: 450px; height:600px"  action="Thanhtoan.php" method="post" style="margin:0 auto">
<table border="5" style="box-shadow:#6DF7DF" align="center"  >
<tr><td style="color:#262323; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">Tên</td><td><input style="width:200px"type="text" name="ten" ></td></tr>
<?php
 if(isset($_SESSION['email']))
				 {
	 				?><tr><td >Email</td><td><?php echo isset($_SESSION['email'])?$_SESSION['email']:"";
				 }
else
{
	?>
    <tr><td style="color:#262323; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">Email</td><td><input style="width:200px"type="email" name="em" ></td></tr>
    <?php
}
?>
<tr><td style="color:#262323 ; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">Địa chỉ</td><td><input style="width:200px" type="text" name="dc" ></td></tr>
<tr><td style="color:#262323 ; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">Tỉnh,thành phố:</td><td><select style="width:200px"name="chonloai">
<option value="Sài Gòn">Sài Gòn</option>
<option value="Cần Thơ">Cần Thơ</option>
<option value="Long An">Long An</option>
<option value="Tiềng Giang">Tiềng Giang</option>
<option value="Hậu Giang">Hậu Giang</option>
<option value="An Giang">An Giang</option></select>
</td></tr>
<tr style="margin-bottom:10px"><td style="margin-bottom:10px ; padding:2px; color:#262323 ; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">Thanh toán</td><td><select style="width:200px"name='tt'>
<option value="Chuyển khoảng" selected>Chuyển khoảng</option>
<option value="trực tiếp">trực tiếp</option>
</select>
</td></tr>
<tr><td style="color:#262323 ; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">Thông tin</td><td><textarea style="width:200px" rows="4" cols="50" name="ms"><?php foreach($_SESSION['giohang'] as $key =>$v)
	{
		
		 echo "tên sản phẫm là:".$_SESSION['giohang'][$key]["ProductName"]."|số lượng là:".$_SESSION['giohang'][$key]['soluong']." ";
	} ?>
    </textarea>
<tr><td style="color:#262323 ; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">Phí ship:</td><td><select style="width:200px" name='ps'>
<option value="0000" selected>nhỏ hơn 10km</option>
<option value="20000">nội thành</option>
<option value="30000">lân cận</option>
<option value="50000">tỉnh</option>
</select>
<tr><td style="color:#262323; background-color:#8EE8FB;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 500;
    font-size: 1.2em; ">SDT:</td><td><input style="width:200px" type="tel" name="sdt" ></td></tr>
<td><center><input  type="submit" name="sm" value="Gửi"></center></td>
</table>
</form></center>
</legend>
</body>

        
        
				   
				   