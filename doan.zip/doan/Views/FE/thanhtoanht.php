<meta charset="utf-8">
<?php
echo "ban da thanh toan xong:"."<br>";?>
<a href="index.php" style="text-decoration:none">Quay lại trang chủ</a>
