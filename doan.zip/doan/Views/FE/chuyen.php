<meta charset="utf-8">
<?php
echo "ban da dang ky thanh cong:"."<br>";?>
<a href="index.php" style="text-decoration:none">Quay lại trang chủ</a>
