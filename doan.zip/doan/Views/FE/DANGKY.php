<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" href="themes/css/style.css">
</head>
<?php
		$em = isset($_POST['em'])?$_POST['em']:"";
		$pass = isset($_POST['pass'])?$_POST['pass']:"";
		$repass = isset($_POST['repass'])?$_POST['repass']:"";
		$dc = isset($_POST['dc'])?$_POST['dc']:"";
		$sdt = isset($_POST['sdt'])?$_POST['sdt']:"";
		$ms=isset($_POST['ms'])?$_POST['ms']:"";	
?>



<body style="background-color:tomato">


<form  style="width: 450px; height:600px"  action="DANGKY.php" method="post" >
<center><header>Đăng ký</header></center>
<label style="margin-left: 88px; font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 800;
    font-size: 1.2em;">Email </label>
    <center> <input style=" width: 65%"  type="email" name="em" value="<?php echo $em ?>"></center>
<label style="margin-left: 88px; font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 800;
    font-size: 1.2em;">Mật khẩu </label>
    <center><input style=" width: 65%"  type="password" name="pass" value="<?php echo $pass ?>"></center>
    <label style="margin-left: 88px; font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 800;
    font-size: 1.2em;">Nhập lại mật khẩu </label>
<center><input style=" width: 65%" type="password" name="repass"value="<?php echo $repass ?>"></center>

<label style="margin-left: 88px; font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 800;
    font-size: 1.2em;">Địa chỉ </label>
    <center><input style=" width: 65%" type="text" name="dc" value="<?php echo $dc ?>"></center>
<label style="margin-left: 88px; font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 800;
    font-size: 1.2em;">Số điện thoại </label><center><input style=" width: 65%" type="tel" name="sdt" value="<?php echo $sdt ?>"></center>

<input style=" position: relative;
  margin-top: 30px;
  margin-bottom: 30px;
  left: 50%;
  transform: translate(-50%, 0);
  font-family: inherit;
  color: white;
  background: #FF3838;
  outline: none;
  border: none;
  padding: 5px 15px;
  font-size: 1.3em;
  font-weight: 400;
  border-radius: 3px;
  box-shadow: 0px 0px 10px rgba(51, 51, 51, 0.4);
  cursor: pointer;
  transition: all 0.15s ease-in-out;
  width: 20%; "type="submit" name="sm" value="Gửi">

</form>

</body>
</html>
<?php

?>

