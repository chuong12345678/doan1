
<?php
function postIndex($index, $value="")
{
	if (!isset($_POST[$index]))	return $value;
	return trim($_POST[$index]);
}
$tk= $_POST["tk"];
  ?>
  <!DOCTYPE html>
<html lang="en">
  <head>
  
    <meta charset="utf-8">
    <title>Bootshop online Shopping cart</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
<!--Less styles -->
   <!-- Other Less css file //different less files has different color scheam
	<link rel="stylesheet/less" type="text/css" href="themes/less/simplex.less">
	<link rel="stylesheet/less" type="text/css" href="themes/less/classified.less">
	<link rel="stylesheet/less" type="text/css" href="themes/less/amelia.less">  MOVE DOWN TO activate
	-->
	<!--<link rel="stylesheet/less" type="text/css" href="themes/less/bootshop.less">
	<script src="themes/js/less.js" type="text/javascript"></script> -->
	
<!-- Bootstrap style --> 
    <link id="callCss" rel="stylesheet" href="themes/bootshop/bootstrap.min.css" media="screen"/>
    <link href="themes/css/base.css" rel="stylesheet" media="screen"/>
<!-- Bootstrap style responsive -->	
	<link href="themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
	<link href="themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->	
	<link href="themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
<!-- fav and touch icons -->
    <link rel="shortcut icon" href="themes/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
  </head>
<body>
<div id="header"> 
<div class="container">
<div id="welcomeLine" class="row">
	<div class="span6">Welcome!<strong>:<?php 
	
		session_start();
	 echo isset($_SESSION['email'])?$_SESSION['email']:"";
	?></strong></div>
	<div class="span6">
	<div class="pull-right">
    <?php
	if( isset($_SESSION['email']))
	{?>
		 <a  style="display:none"href="dangnhap.php"><span class="btn btn-mini btn-primary">Đăng Nhập</span></a>&nbsp
         <?php
	}
	
    else
	{
		?>
     <a href="dangnhap.php"><span class="btn btn-mini btn-primary">Đăng Nhập</span></a>&nbsp
     <?PHP
	}
	 ?>
     <a href="dangnhap.php"><span class="btn btn-mini btn-primary">Đăng Nhập</span></a>&nbsp
        <?php
		$tong=0;
  if(!isset($_SESSION['giohang']))
	{
		?>
        
		<a href="#" ?><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i><?php echo "gio hang co $tong san pham"?></a>
        <?php
	}
	else
	{
		
		foreach($_SESSION['giohang'] as $v)
		{
			
			$tong+=$v['soluong'];
			foreach($_SESSION['giohang'] as $v)
		{	
			if(isset($_SESSION['giohang']['ProductCode']))
			{
				
			}
		}
			
	}
	
		?>
        
		<a href="Product_command.php" ?><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i><?php echo "gio hang co $tong san pham"?></a>
        <?php
	} 
	?></span> </a></div>
	
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>

  <div class="navbar-inner">
  <?php
  foreach($this->goimenu() as $v)
  {
  ?>
    <a class="brand" href="<?php echo $v['Home'] ?>"><img src="themes/images/logo.png" alt="Bootsshop"/></a>
		<form class="form-inline navbar-search" method="post" action='Search.php' >
		<input  type="text" name="tk"/>
        <button type="submit" id="submitButton" class="btn btn-primary" name="sm">Tìm</button>

    </form>
    <ul id="topMenu" class="nav pull-right">
   <li class=""><a href="<?php echo $v['Giới Thiệu'] ?>">Giới Thiệu</a></li>
	
	 <li class=""><a href="<?php echo $v['Liên hệ'] ?>">Liên Hê  </a></li>
    </ul>
  </div>
  <?php
  }
  ?>
</div>
</div>
</div>
<!-- Header End====================================================================== -->
<div id="carouselBlk">
	<div id="myCarousel" class="carousel slide"> <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
		<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
	  </div> 
</div>
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
		
	  <ul id="sideManu" class="nav nav-tabs nav-stacked">
		<li  ><a style="text-align:center" >Danh mục sản phẩm </a>
			</li>
            <?php 
			$arr = $this->htDanhMucSanPham();
				foreach ($arr as &$value) {	
			 ?>
		
			<li  style="background-color:#E3E3E3"><center><a href="products.php?ds=<?php echo $value['tenSP']?>" ><?php echo $value['tenSP']. '(' .$value['soluong'].')' ;?></a><center></li>
		<?php
				}
		?>
		</ul>
		<br/>
<br/>
<br/>
			<div class="thumbnail">
				<img src="themes/images/payment_methods.png" title="Bootshop Payment Methods" alt="Payments Methods">
				<div class="caption">
				  <h5>Payment Methods</h5>
				</div>
	  </div>
	</div>
<!-- Sidebar end=============================================== -->
		<ul class="thumbnails">
              <?php
			 // $a=new sanpham();
			//$sp=$a->sanphamht();
			if(!$mang)
			{
				header("location:index.php");exit;
			}
			  foreach($mang as $v)
			  {	  
			  ?>
				<li class="span3">
				  <div class="thumbnail">
					<a  href="product_details.php?ProductCode=<?php echo $v['ProductCode']?>"><img  height="120px" width="120px" src="<?php echo $v['image']?>" alt=""/></a>
					<div class="caption">
					  <p>Tên <span><?php echo $v['ProductName']?> </span></p>
					<p>Mã: <span><?php echo $v['ProductCode']?></span></p>
                    <p>Danh mục: <span><?php echo $v['ProductList']?></span></p>
					 
					  <h4 style="text-align:center"> <a class="btn" href="#">Thêm vào giỏ <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#"><?php echo $v['price']?></a> </h4>
					</div>
				  </div>
            
				</li>
             <?php
			 	}
			 ?>
             
			  </ul>
              
<!-- Footer ================================================================== -->
	<div   id="footerSection">
	<div style=" font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif; text-align:center"  class="container">
    

Địa chỉ:41 sanhose ,Phường 86 , Quận Cam ,California

ĐIỆN THOẠI LIÊN LẠC :08 62648158
 <br>HOT LINE : 01268 772 788   
<br>GIỜ MỞ CỬA :  10 GIỜ SÁNG- 9 GIỜ TỐI
<p class="pull-right">&copy; Bootshop</p>
	</div><!-- Container End -->
	</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<script src="themes/js/jquery.js" type="text/javascript"></script>
	<script src="themes/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="themes/js/google-code-prettify/prettify.js"></script>
	
	<script src="themes/js/bootshop.js"></script>
    <script src="themes/js/jquery.lightbox-0.5.js"></script>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="themes/switch/themeswitch.css" type="text/css" media="screen" />
<script src="themes/switch/theamswitcher.js" type="text/javascript" charset="utf-8"></script>
	<div id="themeContainer">
	<div id="hideme" class="themeTitle">Style Selector</div>
	<div class="themeName">Oregional Skin</div>
	<div class="images style">
	<a href="themes/css/#" name="bootshop"><img src="themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
	<a href="themes/css/#" name="businessltd"><img src="themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class="active"></a>
	</div>
	<div class="themeName">Bootswatch Skins (11)</div>
	<div class="images style">
		<a href="themes/css/#" name="amelia" title="Amelia"><img src="themes/switch/images/clr/amelia.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="spruce" title="Spruce"><img src="themes/switch/images/clr/spruce.png" alt="bootstrap business templates" ></a>
		<a href="themes/css/#" name="superhero" title="Superhero"><img src="themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="cyborg"><img src="themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="cerulean"><img src="themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="journal"><img src="themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="readable"><img src="themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
		<a href="themes/css/#" name="simplex"><img src="themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="slate"><img src="themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="spacelab"><img src="themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="united"><img src="themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
		<p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
	</div>
	<div class="themeName">Background Patterns </div>
	<div class="images patterns">
		<a href="themes/css/#" name="pattern1"><img src="themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
		<a href="themes/css/#" name="pattern2"><img src="themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern3"><img src="themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern4"><img src="themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern5"><img src="themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern6"><img src="themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern7"><img src="themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern8"><img src="themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern9"><img src="themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern10"><img src="themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>
		
		<a href="themes/css/#" name="pattern11"><img src="themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern12"><img src="themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern13"><img src="themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern14"><img src="themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern15"><img src="themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>
		
		<a href="themes/css/#" name="pattern16"><img src="themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern17"><img src="themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern18"><img src="themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern19"><img src="themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern20"><img src="themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>
		 
	</div>
	</div>
</div>
<span id="themesBtn"></span>
</body>
</html>