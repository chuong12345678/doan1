<meta charset="utf-8">
<html lang="en" >
<head>
  <meta charset="UTF-8">
      <link rel="stylesheet" href="themes/css/style.css">
</head>
<body>


    <form  style="width: 35%;"  action="dangnhap.php" method="post">
     <center><header>Đăng nhập</header></center>
    
    <label style="margin-left: 88px; font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 800;
    font-size: 1.2em;">Email </label>
   <center> <input style=" width: 65%" type="email" name="em" ></center>
   </center> <label style="margin-left: 88px; font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight: 800;
    font-size: 1.2em;">Mật Khẩu <span></span></label></center>
   <center> <input style=" width: 65%" type="password" name="pass" ></center>
    <input  style=" position: relative;
  margin-top: 30px;
  margin-bottom: 30px;
  left: 50%;
  transform: translate(-50%, 0);
  font-family: inherit;
  color: white;
  background: #FF3838;
  outline: none;
  border: none;
  padding: 5px 15px;
  font-size: 1.3em;
  font-weight: 400;
  border-radius: 3px;
  box-shadow: 0px 0px 10px rgba(51, 51, 51, 0.4);
  cursor: pointer;
  transition: all 0.15s ease-in-out;
  width: 20%;
    "type="submit" name="nsm" value="Gửi">
    </form>

</body>
  </html>

  
  


