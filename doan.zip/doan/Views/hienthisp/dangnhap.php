<?php
include "../../config.php";
include(ROOT."/Controllers/Usercontrollers.php");
$dn=new dangky();
$dn->dangnhap();
?>