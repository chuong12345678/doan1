<?php
include "../../config.php";
include(ROOT."/Controllers/FEsanphamcontroler.php");
$a=new sanphamc();
$a->chitietsp();
?>