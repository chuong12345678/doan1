<?php
include "../../config.php";
include(ROOT."/Views/FE/update.php");
?>