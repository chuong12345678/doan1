<?php
include(ROOT."/Controllers/FEsanphamcontroler.php");
$a=new sanphamc();
$a->hienthispc();
?>