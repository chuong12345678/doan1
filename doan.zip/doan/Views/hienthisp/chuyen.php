<?php
include "../../config.php";
include(ROOT."/Controllers/Usercontrollers.php");
$x=new dangky();
$x->chuyentrang();
?>