<?php
include "../../config.php";
include(ROOT."/Controllers/Usercontrollers.php");
$a=new dangky();
$a->dangkyf();
?>