<?php
include "../../config.php";
include(ROOT."/Views/FE/Product_command.php");
?>