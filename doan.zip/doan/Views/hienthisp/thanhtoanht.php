<?php
include "../../config.php";
include(ROOT."/Controllers/Thanhtoancontroler.php");
$a= new thanhtoan();
$a->htthanhtoan();
?>