 <?php
define("HOST", "localhost");
define("DB_NAME", "dochoi");
define("DB_USER", "root");
define("DB_PASS", "");
define('ROOT', dirname(__FILE__) ) ;
//Thu muc tuyet doi truoc cua config; c:/wamp/www/lab/
define("BASE_URL", "http://".$_SERVER['SERVER_NAME']."/lab10/");//dia chi website
