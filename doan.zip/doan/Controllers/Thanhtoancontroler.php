	<meta charset="utf-8">
<?php
include(ROOT."/Models/thanhtoan.php");
session_start();
isset($_SESSION)?$_SESSION:"";
class thanhtoan
{
	
	
	function trangthanhtoan()
			{
		 
		$ten=isset($_POST['ten'])?$_POST['ten']:"";
				if(isset($_SESSION['email']))
				 {
	 				$em=$_SESSION['email'];
				 } 
				 else
				 {
					$em=isset($_POST['em'])?$_POST['em']:"";
				 }
		$dc=isset($_POST['dc'])?$_POST['dc']:"";
		$tinh=isset($_POST['chonloai'])?$_POST['chonloai']:"";
		$ck=isset($_POST['tt'])?$_POST['tt']:"";
		$sdt=isset($_POST['sdt'])?$_POST['sdt']:"";
		$ps=isset($_POST['ps'])?$_POST['ps']:"";
		$ms=isset($_POST['ms'])?$_POST['ms']:"";
		isset($_SESSION)?$_SESSION:"";
		 $tongtien=0;
					 foreach($_SESSION['giohang'] as $key=>$v)  
						   {
								 $_SESSION['giohang'][$key]['tong']= $_SESSION['giohang'][$key]['soluong']*$_SESSION['giohang'		][$key]['price'];
								 $tongtien+=$_SESSION['giohang'][$key]['tong'];
						   }
						
			if(($ten)=="")
			{
				echo"Xin mời nhập tên!<br>";
			}
			else if(($dc)=="")
			{
				echo"Bạn chưa nhập địa chỉ!<br>";
			}
			else if(($sdt)=="")
			{
				echo"Bạn chưa nhập so dien thoai!<br>";
			}
			else if(!(preg_match("/^(0[1-9]{1,2})?([0-9]{9,10})*$/",$sdt)))
			{
				echo "số điện thoại bị sai";
			}
			
			else
			{
				header("location:thanhtoanht.php");
				$_SESSION["ten"]=$ten;
				$_SESSION["em"]=$em;
				$_SESSION["dc"]=$dc;
				$_SESSION["tinh"]=$tinh;
				$_SESSION["ck"]=$ck;
				$_SESSION["sdt"]=$sdt;
				$_SESSION["ps"]=$ps;
				$_SESSION['tien']=$tongtien;
				$_SESSION["ms"]=$ms;
			}
	
	
						  
		include(ROOT."/Views/FE/Thanhtoan.php");
	}
	function htthanhtoan()
	{
		require ROOT.'/smtpmail/PHPMailerAutoload.php';
		$ketnoi=mysqli_connect(HOST,DB_USER,DB_PASS,DB_NAME) or die ('Không thể kết nối tới database');
		$t1=mysqli_real_escape_string($ketnoi,$_SESSION["ten"]);
		$em1=mysqli_real_escape_string($ketnoi,$_SESSION["em"]);
		$dc1=mysqli_real_escape_string($ketnoi,$_SESSION["dc"]);
		$tinh1=mysqli_real_escape_string($ketnoi,$_SESSION["tinh"]);
		$ck1=mysqli_real_escape_string($ketnoi,$_SESSION["ck"]);
		$sdt1=mysqli_real_escape_string($ketnoi,$_SESSION["sdt"]);
		$ms1=mysqli_real_escape_string($ketnoi,$_SESSION["ms"]);
		$ps1=mysqli_real_escape_string($ketnoi,$_SESSION["ps"]);
		$tien= mysqli_real_escape_string($ketnoi,$_SESSION["tien"]);
		$ketnoi=mysqli_connect(HOST,DB_USER,DB_PASS,DB_NAME)or die("ko the ket noi");
		$a=new thanhtoanmodel();
		$a->themthanhtoan($t1,$em1,$dc1,$tinh1,$ck1,$ps1,$ms1,$sdt1,$tien);
		
		include(ROOT."/Views/FE/thanhtoanht.php");
		//SMTP needs accurate times, and the PHP time zone MUST be set
	//This should be done in your php.ini, but this is how to do it if you don't have access to that
	date_default_timezone_set('Etc/UTC');
	
	
	
	//Create a new PHPMailer instance
	$mail = new PHPMailer();
	
	//Tell PHPMailer to use SMTP
	$mail->isSMTP();
	
	//Enable SMTP debugging
	// 0 = off (for production use)
	// 1 = client messages
	// 2 = client and server messages
	$mail->SMTPDebug = 0;
	
	//Ask for HTML-friendly debug output
	$mail->Debugoutput = 'html';
	
	//Set the hostname of the mail server
	$mail->Host = 'smtp.gmail.com';
	
	//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
	$mail->Port =  465;
	
	//Set the encryption system to use - ssl (deprecated) or tls
	$mail->SMTPSecure = 'ssl';
	
	//Whether to use SMTP authentication
	$mail->SMTPAuth = true;
	
	//Username to use for SMTP authentication - use full email address for gmail
	$mail->Username = "anhwadinh911@gmail.com";
	
	//Password to use for SMTP authentication
	$mail->Password = "anhwadinh115";
	
	//Set who the message is to be sent from
	$mail->setFrom('anhwadinh911@gmail.com', 'chuong');
	
	//Set an alternative reply-to address
	$mail->addReplyTo('anhwadinh911@gmail.com', 'chuong');
	
	//Set who the message is to be sent to
	$mail->addAddress($em1);
	
	//Set the subject line
	$mail->Subject = '	Hello:
	' ;
	
	
	
	
	//Read an HTML message body from an external file, convert referenced images to embedded,
	//convert HTML into a basic plain-text alternative body
	$mail->msgHTML(true);
	
	
	//Replace the plain text body with one created manually
	$mail->Body=$t1." đã thanh toán của trang web chung toi<br>Email của bạn là:".$em1."<br> Tổng thanh toán là".$tien." <br> Địa chỉ của bạn là:".$dc1."<br>Số điện thoại là:".$sdt1."<br> phí ship của bạn là:".$ps1."<br>thông tin có trong giỏ hàng là:".$ms1 ;
	$mail->AltBody ='' ;
	
	//Attach an image file
	//$mail->addAttachment('images/phpmailer_mini.png');
	
	//send the message, check for errors
	if (!$mail->send()) {
		echo "lỗi: " . $mail->ErrorInfo;
	} else {
		echo "gửi thành công";
	}
	}
}

?>