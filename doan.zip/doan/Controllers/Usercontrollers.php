<meta charset="utf-8">
<?php
session_start();
include(ROOT."/Models/usermodel.php");
class dangky
{
	function dangkyf()
	{
		$em = isset($_POST['em'])?$_POST['em']:"";
		$pass = isset($_POST['pass'])?$_POST['pass']:"";
		$repass = isset($_POST['repass'])?$_POST['repass']:"";
		$dc = isset($_POST['dc'])?$_POST['dc']:"";
		$sdt = isset($_POST['sdt'])?$_POST['sdt']:"";
		$ketnoi=mysqli_connect(HOST,DB_USER,DB_PASS,DB_NAME)or die("ko the ket noi");
		$sql="select Email from dangky where Email='$em'";
		$kq=mysqli_query($ketnoi,$sql);
		if($em=="")
	{
		
        
		
      
	}
	else if($em=="")
	{
		echo "bạn chưa nhập email:";
	}
	else if(($pass)!=($repass))
	{
		echo "Mật khẩu nhâp lại Không đúng hoăc chưa được nhập!<br>";
	}
	else if(($pass)=="")
	{
		echo"Bạn chưa nhập Mât khẩu!<br>";
	}
	else if(($dc)=="")
	{
		echo"Bạn chưa nhập Mât khẩu!<br>";
	}
	else if(($sdt)=="")
	{
		echo"Bạn chưa nhập so dien thoai!<br>";
	}
	else if((strlen($pass)<8))
	{
		echo "pass phải có ít nhất 8 phần tử!<br>";
	}
	else if(!(preg_match("/^[a-zA-Z0-9._-]*$/",$pass)))
	{
		echo "pass phai co các ký tự và các số!<br>";
	}
	else if(!(preg_match("/^(0[1-9]{1,2})?([0-9]{9,10})*$/",$sdt)))
	{
		echo "số điện thoại bị sai";
	}
	else if(mysqli_fetch_assoc($kq))
	{
		echo "Tài khoản Email đăng ký rồi!";	
	}

	else
	{
		header("location:chuyen.php");
		$_SESSION["em"]=$em;
		$_SESSION["ps"]=$pass;
		$_SESSION["rp"]=$repass;
		$_SESSION["dc"]=$dc;
		$_SESSION["sdt"]=$sdt;
	}
		
		include(ROOT."/Views/FE/DANGKY.php");
	}
	function chuyentrang()
	{
		require ROOT.'/smtpmail/PHPMailerAutoload.php';
		$ketnoi=mysqli_connect(HOST,DB_USER,DB_PASS,DB_NAME) or die ('Không thể kết nối tới database');
		$em=$_SESSION['em'];
		$ps=$_SESSION['ps'];
		$re=$_SESSION['rp'];
		$dc=$_SESSION['dc'];
		$sdt=$_SESSION['sdt'];
		$em1=mysqli_real_escape_string($ketnoi,$em);
			$ps1=mysqli_real_escape_string($ketnoi,$ps);
			$ps1=md5($ps1);
			$re1=mysqli_real_escape_string($ketnoi,$re);
			$re1=md5($re1);
			$dc1=mysqli_real_escape_string($ketnoi,$dc);
			$sdt1=mysqli_real_escape_string($ketnoi,$sdt);
		$a=new usermodel();
		$a->adduser($em1,$ps1,$re1,$dc1,$sdt1);
		
	
	//SMTP needs accurate times, and the PHP time zone MUST be set
	//This should be done in your php.ini, but this is how to do it if you don't have access to that
	date_default_timezone_set('Etc/UTC');
	
	
	
	//Create a new PHPMailer instance
	$mail = new PHPMailer();
	
	//Tell PHPMailer to use SMTP
	$mail->isSMTP();
	
	//Enable SMTP debugging
	// 0 = off (for production use)
	// 1 = client messages
	// 2 = client and server messages
	$mail->SMTPDebug = 0;
	
	//Ask for HTML-friendly debug output
	$mail->Debugoutput = 'html';
	
	//Set the hostname of the mail server
	$mail->Host = 'smtp.gmail.com';
	
	//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
	$mail->Port =  465;
	
	//Set the encryption system to use - ssl (deprecated) or tls
	$mail->SMTPSecure = 'ssl';
	
	//Whether to use SMTP authentication
	$mail->SMTPAuth = true;
	
	//Username to use for SMTP authentication - use full email address for gmail
	$mail->Username = "anhwadinh911@gmail.com";
	
	//Password to use for SMTP authentication
	$mail->Password = "anhwadinh115";
	
	//Set who the message is to be sent from
	$mail->setFrom('anhwadinh911@gmail.com', 'chuong');
	
	//Set an alternative reply-to address
	$mail->addReplyTo('anhwadinh911@gmail.com', 'chuong');
	
	//Set who the message is to be sent to
	$mail->addAddress($em1);
	
	//Set the subject line
	$mail->Subject = '	Hello:
	' ;
	
	
	
	
	//Read an HTML message body from an external file, convert referenced images to embedded,
	//convert HTML into a basic plain-text alternative body
	$mail->msgHTML(true);
	
	//Replace the plain text body with one created manually
	$mail->Body="Bạn đã là thành viên của trang web chung toi:http://chuongpham.ga/doanupload/Views/hienthisp/<br>Email của bạn là:".$em1."<br> Mật khẩu của bạn là:".$ps." <br> Địa chỉ của bạn là:".$dc1."<br>Số điện thoại là:".$sdt1;
	$mail->AltBody ='' ;
	
	//Attach an image file
	//$mail->addAttachment('images/phpmailer_mini.png');
	
	//send the message, check for errors
	if (!$mail->send()) {
		echo "lỗi: " . $mail->ErrorInfo;
	} else {
		echo "gửi thành công";
	}
		include(ROOT."/Views/FE/chuyen.php");
	}
	function dangnhap()
	{
			
		if(isset($_SESSION['email']))
		{
			header("location:index.php");
			
		}
		else
		{		
		if(isset($_POST['nsm']))
		{
			$c_dn=new usermodel();
			
			if($c_dn->user($_POST["em"],md5($_POST["pass"])))
			{
				header("location:index.php");
				$_SESSION["email"]=$_POST["em"];
			}
			else if(!($c_dn->user($_POST["em"],md5($_POST["pass"]))))
			{
				echo "chua ton tai email bạn có thể đang ký tại trang chính:";
			}
			else
			{
				echo "Sai mật khẩu hoặc email xin vui lòng nhập lại:";
			}
			
		}
		include(ROOT."/Views/FE/dangnhap.php");
	}
	
	}
}
?>