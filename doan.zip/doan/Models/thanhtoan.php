<meta charset="utf-8">
<?php
	require_once('db.php');
	class thanhtoanmodel extends database
	{
		function themthanhtoan($t,$em,$dc,$tinh,$ck,$ps,$ms,$sdt,$tien)
		{
			$sql="insert into thanhtoan (Name,Email,Diachi,Tinh,Thanhtoan,Phiship,product,sdt,tongtien)values ('$t','$em','$dc','$tinh','$ck','$ps','$ms','$sdt','$tien')";
			$this->setQuery($sql);
			 return $this->laytoanbodulieu();
			
		}
	}
?>