<?php
	require_once('db.php');
	class usermodel extends database
	{
		function adduser($em,$ps,$re,$dc,$sdt)
		{
			
			$sql="insert into dangky (Email,pass,Repass,Diachi,SDT)values ('$em','$ps','$re','$dc','$sdt')";
			 $this->setQuery($sql);
			 return $this->laytoanbodulieu();
			
			
		}
		function user($em,$sp)
		{
			$sql="select * from dangky where Email='$em' and pass='$sp' ";
			$this->setQuery($sql);
			return $this->LoadAllRow();
		}
		
		
	}
	
	
?>